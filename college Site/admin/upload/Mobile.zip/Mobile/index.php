<?php include('includes/header.php') ?>


    <div id="content">
<form name="myform" method="post" onsubmit="return formValdation()" >
<center><h3>Add New Customer  Information</h3></center>
	<table cellspacing="10">
    	<tr>
        	<th>Customer Name:</th>
            <td><input type="text" name="cname" id="cname" onclick="this.value=''" /></td>
            
            
            
        
        	<th>Model Number:</th>
            <td><input type="text" name="modelnumber" onclick="this.value=''" /></td>
        </tr>
        <tr>
        	<th>IMEI:</th>
            <td><input type="text" name="imei" onclick="this.value=''"/></td>
       
        	<th>Date:</th>
            <td><input type="text" name="date" onclick="this.value=''" /> <a href="#" onClick="setYears(1947, 2020);
       showCalender(this, 'date');">
      <img src="images/calender.png"></a></td>
         </tr>
       	<tr> 	<th>Mobile Repairing Status:</th>
            <td>
            	<select name="status">
                	<option>Select Mobile Status</option>
                    <option>Yes</option>
                    <option>No</option>
                </select>
            </td>
        
        	<th>Fault:</th>
            <td><input type="text" name="fault"  onclick="this.value=''"/></td>
        </tr>
        
        <tr>
        	<th>Total Amount:</th>
            <td><input type="text" name="totalamount" onfocus="strtCalc()" onblur="stopcalc()" onclick="this.value=''"/></td>
        
        	<th>Advance Amount:</th>
            <td><input type="text" name="advanceamount" value="0"  onfocus="strtCalc()" onblur="stopcalc()" onclick="this.value=''"/></td>
        </tr>
        <tr>
        	<th>Remaining Amout:</th>
            <td><input type="text" name="remainamount"    disabled="disabled" /></td>
            <th colspan="2">Battery <input type="checkbox"  name="battery" value="Battery"/>
                 Charger <input type="checkbox" name="charger" value="Charger" />
                 Casing <input type="checkbox" name="casing" value="Casing" />
                 SIM <input type="checkbox" name="sim" value="SIM" /></td>
        </tr>
        <tr>
        	<th>Description:</th>
            <td><textarea name="description"></textarea></td>
        </tr>
        <tr>
        	<td></td>
            <td></td>
            <td></td>
            <td align="right"><input type="submit" value="Add Record" /></td>
        </tr>
    </table>
<table id="calenderTable">
        <tbody id="calenderTableHead">
          <tr>
            <td colspan="4" align="center">
	          <select onChange="showCalenderBody(createCalender(document.getElementById('selectYear').value,
	           this.selectedIndex, false));" id="selectMonth">
	              <option value="0">Jan</option>
	              <option value="1">Feb</option>
	              <option value="2">Mar</option>
	              <option value="3">Apr</option>
	              <option value="4">May</option>
	              <option value="5">Jun</option>
	              <option value="6">Jul</option>
	              <option value="7">Aug</option>
	              <option value="8">Sep</option>
	              <option value="9">Oct</option>
	              <option value="10">Nov</option>
	              <option value="11">Dec</option>
	          </select>
            </td>
            <td colspan="2" align="center">
			    <select onChange="showCalenderBody(createCalender(this.value, 
				document.getElementById('selectMonth').selectedIndex, false));" id="selectYear">
				</select>
			</td>
            <td align="center">
			    <a href="#" onClick="closeCalender();"><font color="#003333" size="+1">Close</font></a>
			</td>
		  </tr>
       </tbody>
       <tbody id="calenderTableDays">
         <tr style="">
           <td>Sun</td><td>Mon</td><td>Tue</td><td>Wed</td><td>Thu</td><td>Fri</td><td>Sat</td>
         </tr>
       </tbody>
       <tbody id="calender"></tbody>
    </table>
</form>
<?php include('connection.php')?>
<?php 

			$cat='';
		if(isset($_POST['cname'])){
			
			if(isset($_POST['battery'])){
			$cat= $_POST['battery'].',';
			}
			if(isset($_POST['charger'])){
			$cat.= $_POST['charger'].',';
			}
			if(isset($_POST['casing'])){
			$cat.= $_POST['casing'].',';
			}
			if(isset($_POST['sim'])){
			$cat.= $_POST['sim'];
			}
			
			
	$insertRecord="INSERT INTO mobileinfo VALUES(NULL,'$_POST[cname]','$_POST[modelnumber]','$_POST[imei]','$_POST[date]','$_POST[fault]','$_POST[description]','$_POST[status]','$_POST[totalamount]','$_POST[advanceamount]','$cat')";
		$query=mysql_query($insertRecord);
			if(!$query)
			{
				die('Record Not Add '.mysql_error());
			}
		}

?>
</div><!--end content--->
<?php include('includes/footer.php') ?>