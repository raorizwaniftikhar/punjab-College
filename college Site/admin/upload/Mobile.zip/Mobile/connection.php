<?php 
	$connection=mysql_connect('localhost','root','');
		if(!$connection){
			die('Connection Not Created'.mysql_error());
		}
	$db=mysql_select_db('mobiledb');
		if(!$db){
			die("Can't Select database".mysql_error());
		}
		
	
?>