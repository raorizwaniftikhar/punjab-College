<?php include('connection.php') ?>
<?php include('includes/header.php') ?>
<div id="content">
<center>
	<form action="" name="search" method="post">
    	<table>
        	<tr>
                <td>Enter Name Or Mode No Or IMEI</td>
            </tr>
            <tr>
                <td><input type="text" name="name" id="theValue" onkeypress="checkDelay()"/></td>
            </tr>
            <tr>
            	<td  align="left"><input type="button" value="Search"  onclick="myAjax()"  /></td>
            </tr>
        </table>
    </form>
</center>
    <br />
 <div id='result'>

<div id="txtHint"><b>Person info will be listed here.</b></div>
</div>
</div><!--end content-->

<?php include('includes/footer.php') ?>