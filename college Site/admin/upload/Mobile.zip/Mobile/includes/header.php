<?php include('connection.php') ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Al-Rehman Mobile Repairing Lab</title>
<link  rel="stylesheet" type="text/css" href="style.css" />
<script language="javaScript" type="text/javascript" src="calendar.js"></script>
   <link href="calendar.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="js/jquery-latest.js"></script>
<script type="text/javascript">
	function formValdation(){
		var cname=document.myform.cname.value;
		var modelnumber=document.myform.modelnumber.value;
		var imei=document.myform.imei.value;
		var date=document.myform.date.value;
		var status=document.myform.status.value;
		var fault=document.myform.fault.value;
		var totalamount=document.myform.totalamount.value;
			if((cname=='')||(cname=='Require Field')){
				document.myform.cname.value="Require Field";
				document.myform.cname.focus();
				return false;
			}
			if((modelnumber=='')||(modelnumber=='Require Field')){
				document.myform.modelnumber.value="Require Field";
				document.myform.modelnumber.focus();
				return false;
			}
			if((imei=='')||(imei=='Require Field')){
				document.myform.imei.value="Require Field";
				document.myform.imei.focus();
				return false;
			}
			if((date=='')||(date=='Require Field')){
				document.myform.date.value="Require Field";
				document.myform.date.focus();
				return false;
			}
			if((status=='')||(status=='Select Mobile Status')){
				
				document.myform.status.focus();
				return false;
			}
			if((fault=='')||(fault=='Require Field')){
				document.myform.fault.value="Require Field";
				document.myform.fault.focus();
				return false;
			}
			if((totalamount=='')||(totalamount=='Require Field')){
				document.myform.totalamount.value="Require Field";
				document.myform.totalamount.focus();
				return false;
			}
			
			
		return true;
	}
	function strtCalc(){
		interval=setInterval("calculatAmount()",1);
	}
	function calculatAmount(){
		
		var totalamount=document.myform.totalamount.value;
		var advanceamount=document.myform.advanceamount.value;
		
		document.myform.remainamount.value=(totalamount*1)-(advanceamount*1);
		
	}
	function stopcalc(){
		clearInterval(interval);
	}
	
</script>
<script type="text/javascript">
function myAjax()
{
	$('#txtHint').fadeOut(1);
	$.post(
		'getuser.php',
		{
			name: $('#theValue').val()
		},
		function(data)
		{
			$('#txtHint').fadeIn(1000);
			$('#txtHint').html(data);
		}
	);
}
var interval;
function checkDelay()
{
	clearInterval(interval);
	interval = setTimeout('myAjax()', 1000);
}
</script>
</head>

<body>

<div id="wrapper">
	<div id="header">
    	<div id="logo">
    		<img src="images/logo.png"  />
        </div>
        <h1>AL-Rehman Mobile Repairing Lab </h1>
    </div><!--end header-->
    <div id="access">
    	<ul>
        	<li><a href="index.php">Home</a></li>
            <li><a href="search.php">Search</a></li>
            
        </ul>
    </div><!--end access-->
   