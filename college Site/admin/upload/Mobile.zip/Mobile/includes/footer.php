<div id="footer">
	<p>Copyright &copy; 2012 AL-Rehman Mobile| All Right Reserved

    | Privacy Policy
    | Terms & Condition</p>
</div>
</div><!--end wrapper-->
</body>
</html>