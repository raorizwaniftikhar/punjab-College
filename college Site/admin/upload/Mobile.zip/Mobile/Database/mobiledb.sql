-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 30, 2012 at 06:30 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mobiledb`
--

-- --------------------------------------------------------

--
-- Table structure for table `mobileinfo`
--

CREATE TABLE IF NOT EXISTS `mobileinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CName` varchar(30) NOT NULL,
  `modelNo` varchar(20) NOT NULL,
  `IMEI` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `fault` varchar(20) NOT NULL,
  `description` varchar(300) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `totalAmount` int(11) NOT NULL,
  `advanceAmount` int(11) NOT NULL,
  `category` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `mobileinfo`
--

INSERT INTO `mobileinfo` (`id`, `CName`, `modelNo`, `IMEI`, `date`, `fault`, `description`, `status`, `totalAmount`, `advanceAmount`, `category`) VALUES
(1, 'Dilshad', 'Nokia 1100', '123', '0000-00-00', 'asd', 'test', 0, 100, 20, 'Casing,,,'),
(2, 'Dilshad', 'Nokia 1100', '123', '0000-00-00', 'asd', 'test', 0, 100, 70, 'Casing,,,'),
(3, 'Dilshad', 'Nokia 1100', '123', '0000-00-00', 'asd', '', 0, 30, 0, 'Casing,,,'),
(4, 'Dilshad', 'Nokia 1100', '123', '0000-00-00', 'asd', '', 0, 100, 0, 'Array'),
(5, 'Dilshad', 'Nokia 1100', '123', '0000-00-00', 'asd', '', 0, 100, 0, '$battery,$sim,$charger,$casing'),
(6, 'Dilshad', 'Nokia 1100', '123', '0000-00-00', 'asd', '', 0, 100, 0, 'SIM,,,'),
(7, 'Dilshad', 'Nokia 1100', '123', '0000-00-00', 'asd', '', 0, 100, 0, 'SIM,,,'),
(8, 'Dilshad', 'Nokia 1100', '123', '0000-00-00', 'asd', '', 0, 100, 0, ',,,'),
(9, 'ddsds', '3232234', '234342234234', '0000-00-00', 'dssd', 'dddssdfsd', 0, 23, 20, ''),
(10, 'ssadsad', '2332342', '324342234', '0000-00-00', 'dd', 'zxxxzc', 0, 234, 34, ''),
(11, 'dadsads', '22332', '322323', '0000-00-00', 'dsds', 'zxx', 0, 445, 44, ''),
(12, 'sd', '332', '322332', '0000-00-00', 'sadsad', 'xds', 0, 123, 44, ''),
(13, 'dsd', '3232', '3232', '0000-00-00', '223', 'xxcc', 0, 23, 0, 'Battery,Charger,Casing,,'),
(14, 'dsd', '3232', '3232', '0000-00-00', '223', 'xxcc', 0, 23, 0, 'Battery,Charger,Casing,'),
(15, 'sdfsfd', '233', '3444', '0000-00-00', 'dfg', 'dd', 0, 345, 0, 'Battery,Charger,Casing,'),
(16, 'Dilshad', 'Nokia 1100', '123', '0000-00-00', 'asd', '', 0, 100, 10, 'Charger,Casing,'),
(17, 'Dilshad', 'Nokia 1100', '123', '0000-00-00', 'dfg', '', 0, 90, 0, 'Charger,Casing,'),
(18, 'Dilshad', 'Nokia 1100', '123', '2011-01-01', 'asd', '', 0, 100, 0, 'Charger,'),
(19, 'Dilshad', 'Nokia 1100', '123', '03-01-2012', 'asd', '', 0, 100, 0, 'SIM,'),
(20, 'Dilshad', 'Nokia 1100', '123', '02-01-2012', 'asd', '', 0, 100, 0, 'Charger,'),
(21, 'Shumail altaf', 'Andriod', '234', '04-01-2012', 'low battery', 'test', 0, 300, 200, 'Charger,Casing,'),
(22, 'Fahad Subhan', 'Andriod', '234', '02-01-2012', 'Bad charging worring', 'this is text area ', 0, 300, 30, 'Battery,Charger,Casing,SIM');
