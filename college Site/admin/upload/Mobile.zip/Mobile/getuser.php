<?php
      include('connection.php');
	  $q=$_POST["name"];
	  if ($q == "")
	  {
	  	echo 'Please enter search value'; die;
	  }

$sql="SELECT * FROM mobileinfo WHERE CName LIKE '%".$q."%' or modelNo LIKE '%".$q."%'";

$result = mysql_query($sql) or die(mysql_error());

echo "<table border='1'>
<tr>
<th>Customer Name</th>
<th>Mobile Model</th>
<th>IMEI</th>
<th>Date</th>
<th>Fault</th>
<th>Repair Status</th>
<th>Others</th>
<th>Total Amount</th>
<th>Advance Amount</th>
<th>Remainin Amount</th>
<th>Description</th>
</tr>";
$totalAmount='';
$advanceAmount='';
$remainingAmount='';
while($row = mysql_fetch_array($result))
  {
	  $totalAmount=$row['totalAmount'];
	  $advanceAmount=$row['advanceAmount'];
	  $remainingAmount=$totalAmount-$advanceAmount;
	  
  echo "<tr>";
  echo "<td>".$row['CName']."</td>";
  echo "<td>".$row['modelNo']."</td>";
  echo "<td>".$row['IMEI']."</td>";
  echo "<td>".$row['date']."</td>";
  echo "<td>".$row['fault']."</td>";
  echo "<td>".$row['status']."</td>";
   echo "<td>".$row['category']."</td>";
  echo "<td>".$row['totalAmount']."</td>";
  echo "<td>".$row['advanceAmount']."</td>";
 
  echo "<td>".$remainingAmount."</td>";
   echo "<td>".$row['description']."</td>";
  echo "</tr>";
  }
echo "</table>";


?> 